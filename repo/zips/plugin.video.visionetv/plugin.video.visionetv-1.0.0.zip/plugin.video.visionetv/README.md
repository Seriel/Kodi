# plugin.video.salvo 1.0.1
Kodi unofficial Plugin for Visione TV
