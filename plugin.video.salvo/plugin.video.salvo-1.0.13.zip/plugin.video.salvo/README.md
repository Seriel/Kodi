# plugin.video.salvo 1.0.8
Kodi unofficial Plugin for WEB TV Salvo5puntozero
